# PersonalExpenseManagement

### Guia de inicio

* entrar en la carpeta PersonalExpenseManagement

> `cd PersonalExpenseManegment.services.ts`

* insalar dependencias

> `npm install`

* levantar web

> `npm run start`